﻿/* yardım tuşu */
/*
$('#ribbon').append('<div style="margin-top: 0px;" class="demo"><span id="demo-setting"><i class="fa fa-info fa-spin txt-color-blueDark"></i></span> <form><legend class="no-padding margin-bottom-10">Kasa Takip Sistemi</legend><section><a href="javascript:alert(\'Hazırlanacak\');"><i class="fa fa-share"> İstek ve Öneri Bildir</i></a></section><section><a href="javascript:alert(\'Hazırlanacak\');"><font color=red><i class="fa fa-exclamation"> Hata Bildir</i></font></a></section></form> </div>');
$('#demo-setting').click(function () {
    $('.demo').toggleClass('activate')
});
*/
function b64EncodeUnicode(str) {
    return btoa(encodeURIComponent(str).replace(/%([0-9A-F]{2})/g, function (match, p1) {
        return String.fromCharCode('0x' + p1);
    }));
}
function b64DecodeUnicode(str) {
    return decodeURIComponent(Array.prototype.map.call(atob(str), function (c) {
        return '%' + ('00' + c.charCodeAt(0).toString(16)).slice(-2);
    }).join(''));
}

Number.prototype.FormatMoney = function (c, d, t) {
    var n = this,
		c = isNaN(c = Math.abs(c)) ? 2 : c,
		d = d == undefined ? "." : d,
		t = t == undefined ? "," : t,
		s = n < 0 ? "-" : "",
		i = parseInt(n = Math.abs(+n || 0).toFixed(c)) + "",
		j = (j = i.length) > 3 ? j % 3 : 0;
    return s + (j ? i.substr(0, j) + t : "") + i.substr(j).replace(/(d{3})(?=d)/g, "$1" + t) + (c ? d + Math.abs(n - i).toFixed(c).slice(2) : "");
};
String.prototype.GetMoney = function (c, d) {
    var n = this;
    return parseFloat(n.replace(c, "").replace(d, c));
};
